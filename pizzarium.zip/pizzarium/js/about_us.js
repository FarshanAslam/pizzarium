$(document).ready(function(){

$('#head_chef_img').hover(

  function(){$('#head_chef').show();},
  function(){$('#head_chef').hide();},
);

$('#assistant_chef_img').hover(

  function(){$('#assistant_chef').show();},
  function(){$('#assistant_chef').hide();},
);

$('#wood_burning_img').hover(
  function(){$('#wood_burning').show();},
  function(){$('#wood_burning').hide();},
);

});
